package bg.tu_varna.sit.f24621905.task2;

public class Character {
    private String Name;
    private int Life;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public int getLife() {
        return Life;
    }

    public void setLife(int life) {
        Life = life;
    }
}
