package bg.tu_varna.sit.f24621905.task1;

public class Machine {
    private double price;

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
